using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using App.Models.Product;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using App.Models.Product.Models;
using System.Linq;

using App.Models;

namespace AppMvc.Net.Areas.Product.Controllers
{
    public class CartController : Controller
    {
        private readonly AppDbContext _appDbContext;
        private readonly HttpContext _HttpContext;
        private readonly IHttpContextAccessor _context;
        private const string CartSession = "CartSession";
        public CartController(AppDbContext appDbContext,HttpContextAccessor context){
            _appDbContext = appDbContext;
            _HttpContext = _context.HttpContext;
            var Session = _HttpContext.Session;
            
        }

    }
}